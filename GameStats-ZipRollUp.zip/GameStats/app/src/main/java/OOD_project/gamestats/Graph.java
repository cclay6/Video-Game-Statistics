package OOD_project.gamestats;

//old class used for development
//not used in final product
public class Graph {

}
