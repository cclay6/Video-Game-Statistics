package OOD_project.gamestats;

/**
 * Filters the gamelist. Not used in final product.
 */
public class Filter {

    public GameList byCompleted(GameList gameList)
    {
        return gameList;
    }

    public GameList byNotCompleted(GameList gameList)
    {
        return gameList;
    }

    public GameList byInProgress(GameList gameList)
    {
        return gameList;
    }

    public GameList byNotInProgress(GameList gameList)
    {
        return gameList;
    }

    public GameList byConsole(GameList gameList)
    {
        return gameList;
    }

    public GameList byYear(GameList gameList)
    {
        return gameList;
    }
}
